# -*- coding: utf-8 -*-
from tkinter import *
from tkinter import messagebox, ttk
from PIL import Image, ImageTk, ImageDraw
import sqlite3
import time
from datetime import datetime
from math import *
import os

# Import your custom modules (make sure these files exist)
from course import CourseClass
from student import StudentClass
from result import resultClass
from report import reportClass

# Main Application Class
class RMS:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Result Management System")
        self.root.state('zoomed')  # Full screen
        self.root.config(bg="white")

        # Get screen width and height
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()

        # ============ Load multiple background images ============
        self.bg_images = [
            ImageTk.PhotoImage(Image.open("C:/RMS/RMS/images/pexels-cottonbro-4778661.jpg").resize((self.screen_width, self.screen_height), Image.LANCZOS)),
            ImageTk.PhotoImage(Image.open("C:/RMS/RMS/images/pexels-max-fischer-5212340.jpg").resize((self.screen_width, self.screen_height), Image.LANCZOS)),
            ImageTk.PhotoImage(Image.open("C:/RMS/RMS/images/pexels-pixabay-461069.jpg").resize((self.screen_width, self.screen_height), Image.LANCZOS)),
            ImageTk.PhotoImage(Image.open("C:/RMS/RMS/images/pexels-yankrukov-8199708.jpg").resize((self.screen_width, self.screen_height), Image.LANCZOS)),
            ImageTk.PhotoImage(Image.open("C:/RMS/RMS/images/pexels-137666-710743.jpg").resize((self.screen_width, self.screen_height), Image.LANCZOS))
        ]
        self.current_bg_index = 0

        # Background Label
        self.bg_label = Label(self.root)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)
        self.slider_background()

        # ============ Title Section ============
        logo_img = Image.open("images/logo_p.png")
        self.logo_dash = ImageTk.PhotoImage(logo_img)

        title = Label(self.root, text="Student Result Management System", padx=10,
                      image=self.logo_dash, compound=LEFT,
                      font=("goudy old style", 20, "bold"),
                      bg="#033054", fg="white")
        title.place(x=0, y=0, relwidth=1, height=50)

        # ============ Menu Frame ============
        M_Frame = LabelFrame(self.root, text="Menus", font=("times new roman", 15), bg="white")
        M_Frame.place(x=10, y=70, width=1340, height=80)

        Button(M_Frame, text="Course", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.add_course).place(x=20, y=5, width=200, height=40)

        Button(M_Frame, text="Student", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.add_student).place(x=240, y=5, width=200, height=40)

        Button(M_Frame, text="Result", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.add_result).place(x=460, y=5, width=200, height=40)

        Button(M_Frame, text="View Student Results", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.add_report).place(x=680, y=5, width=200, height=40)

        Button(M_Frame, text="Logout", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.logout).place(x=900, y=5, width=200, height=40)

        Button(M_Frame, text="Exit", font=("goudy old style", 15, "bold"), bg="#0b5377", fg="white",
               cursor="hand2", command=self.exit_).place(x=1120, y=5, width=200, height=40)

        # ============ Dashboard Boxes ============
        self.lbl_course = Label(self.root, text="Total Courses\n[0]",
                                font=("goudy old style", 20), bd=10, relief=RIDGE,
                                bg="#e43b06", fg="white")
        self.lbl_course.place(x=400, y=530, width=300, height=100)

        self.lbl_students = Label(self.root, text="Total Students\n[0]",
                                  font=("goudy old style", 20), bd=10, relief=RIDGE,
                                  bg="#0676ad", fg="white")
        self.lbl_students.place(x=710, y=530, width=300, height=100)

        self.lbl_result = Label(self.root, text="Total Results\n[0]",
                                font=("goudy old style", 20), bd=10, relief=RIDGE,
                                bg="#038074", fg="white")
        self.lbl_result.place(x=1020, y=530, width=300, height=100)

        # ============ Clock Section ============
        self.lbl = Label(self.root, text=" \n DHARSHAN CLOCK", font=("Book Antiqua", 22, "bold"),
                         fg="white", compound=BOTTOM, bg="#081923", bd=0)
        self.lbl.place(x=10, y=180, height=450, width=350)

        self.working()
        self.update_details()

        # ============ Footer ============
        footer = Label(self.root,
                       text="SRMS-Student Result Management System\nContact US for any Technical Issue: 987xxxx01",
                       font=("goudy old style", 12),
                       bg="#262626", fg="white")
        footer.pack(side=BOTTOM, fill=X)

        # ============ Raise important widgets ============
        title.lift()
        M_Frame.lift()
        self.lbl_course.lift()
        self.lbl_students.lift()
        self.lbl_result.lift()
        self.lbl.lift()
        footer.lift()

    # ============ Slider Background ============
    def slider_background(self):
        self.bg_label.config(image=self.bg_images[self.current_bg_index])
        self.current_bg_index = (self.current_bg_index + 1) % len(self.bg_images)
        self.root.after(3000, self.slider_background)

    # ============ Update Stats ============
    def update_details(self):
        try:
            con = sqlite3.connect(database="rms.db")
            cur = con.cursor()

            cur.execute("SELECT * FROM course")
            self.lbl_course.config(text=f"Total Courses\n[{len(cur.fetchall())}]")

            cur.execute("SELECT * FROM student")
            self.lbl_students.config(text=f"Total Students\n[{len(cur.fetchall())}]")

            cur.execute("SELECT * FROM result")
            self.lbl_result.config(text=f"Total Results\n[{len(cur.fetchall())}]")

            self.lbl_course.after(200, self.update_details)
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to {str(ex)}", parent=self.root)

    # ============ Analog Clock Updater ============
    def working(self):
        now = datetime.now()
        hr = (now.hour % 12) * 30 + (now.minute / 60) * 30
        min_ = (now.minute / 60) * 360
        sec_ = (now.second / 60) * 360

        self.clock_image(hr, min_, sec_)
        self.img = ImageTk.PhotoImage(file="clock_new.png")
        self.lbl.config(image=self.img)
        self.lbl.after(200, self.working)

    def clock_image(self, hr, min_, sec_):
        clock = Image.new("RGB", (400, 400), (8, 25, 35))
        draw = ImageDraw.Draw(clock)

        bg = Image.open("images/c.png").resize((300, 300), Image.LANCZOS)
        clock.paste(bg, (50, 50))

        origin = (200, 200)

        draw.line((origin, 200 + 50 * sin(radians(hr)), 200 - 50 * cos(radians(hr))), fill="#DF005E", width=4)
        draw.line((origin, 200 + 80 * sin(radians(min_)), 200 - 80 * cos(radians(min_))), fill="white", width=3)
        draw.line((origin, 200 + 100 * sin(radians(sec_)), 200 - 100 * cos(radians(sec_))), fill="yellow", width=2)

        draw.ellipse((195, 195, 210, 210), fill="#1AD5D5")

        clock.save("clock_new.png")

    # ============ Button Commands ============
    def add_course(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = CourseClass(self.new_win)

    def add_student(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = StudentClass(self.new_win)

    def add_result(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = resultClass(self.new_win)

    def add_report(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = reportClass(self.new_win)

    def logout(self):
        op = messagebox.askyesno("Confirm", "Do you really want to logout?", parent=self.root)
        if op:
            self.root.destroy()
            os.system("python login.py")

    def exit_(self):
        op = messagebox.askyesno("Confirm", "Do you really want to Exit?", parent=self.root)
        if op:
            self.root.destroy()

# ============ Main Launcher ============
if __name__ == "__main__":
    root = Tk()
    obj = RMS(root)
    root.mainloop()
