from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import sqlite3

class resultClass:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Result Management System")
        self.root.geometry("1200x480+80+170")
        self.root.config(bg="white")
        self.root.focus_force()

        # ===== Variables =====
        self.roll_list = []
        self.var_roll = StringVar()
        self.var_name = StringVar()
        self.var_course = StringVar()
        self.var_marks = StringVar()
        self.var_full_marks = StringVar()

        # ===== Combobox - Define before fetch_roll() =====
        self.txt_student = ttk.Combobox(self.root, textvariable=self.var_roll, values=self.roll_list,
                                        font=("goudy old style", 15, 'bold'),
                                        state='readonly', justify=CENTER)
        self.txt_student.place(x=280, y=100, width=200)
        self.txt_student.set("Select")

        # ===== Call roll fetch function =====
        self.fetch_roll()

        # ===== Title Label =====
        title = Label(self.root, text="ADD Student Results",
                      font=("goudy old style", 20, "bold"),
                      bg="orange", fg="#262626")
        title.place(x=10, y=15, width=1180, height=50)

        # ===== Labels =====
        Label(self.root, text="Select Student", font=("goudy old style", 20, "bold"), bg="white").place(x=50, y=100)
        Label(self.root, text="Name", font=("goudy old style", 20, "bold"), bg="white").place(x=50, y=160)
        Label(self.root, text="Course", font=("goudy old style", 20, "bold"), bg="white").place(x=50, y=220)
        Label(self.root, text="Marks Obtained", font=("goudy old style", 20, "bold"), bg="white").place(x=50, y=280)
        Label(self.root, text="Full Marks", font=("goudy old style", 20, "bold"), bg="white").place(x=50, y=340)

        # ===== Entries =====
        Button(self.root, text='Search', font=("goudy old style", 15, "bold"),
               bg="#03a9f4", fg="white", cursor="hand2", command=self.search).place(x=500, y=100, width=100, height=28)

        Entry(self.root, textvariable=self.var_name, font=("goudy old style", 20, 'bold'),
              bg='lightyellow', state="readonly").place(x=280, y=160, width=320)

        Entry(self.root, textvariable=self.var_course, font=("goudy old style", 20, 'bold'),
              bg='lightyellow', state="readonly").place(x=280, y=220, width=320)

        Entry(self.root, textvariable=self.var_marks, font=("goudy old style", 20, 'bold'),
              bg='lightyellow').place(x=280, y=280, width=320)

        Entry(self.root, textvariable=self.var_full_marks, font=("goudy old style", 20, 'bold'),
              bg='lightyellow').place(x=280, y=340, width=320)

        # ===== Buttons =====
        Button(self.root, text="Submit", font=("times new roman", 15),
               bg="lightgreen", activebackground="lightgreen",
               cursor="hand2", command=self.add).place(x=300, y=420, width=120, height=35)

        Button(self.root, text="Clear", font=("times new roman", 15),
               bg="lightgray", activebackground="lightgray",
               cursor="hand2", command=self.clear).place(x=430, y=420, width=120, height=35)

        # ===== Result Image =====
        try:
            img = Image.open("images/result.jpg").resize((500, 300), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            label = Label(self.root, image=photo)
            label.image = photo
            label.place(x=650, y=100)
        except Exception as e:
            messagebox.showerror("Image Error", f"Cannot load image.\n{str(e)}")

    # ===== Function to Fetch Roll Numbers from Database =====
    def fetch_roll(self):
        con = sqlite3.connect(database="rms.db")
        cur = con.cursor()
        try:
            cur.execute("SELECT roll FROM student")
            rows = cur.fetchall()
            if rows:
                self.roll_list = [row[0] for row in rows]
                self.txt_student['values'] = self.roll_list  # Update combobox

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to {str(ex)}", parent=self.root)

    # ===== Search Button Function =====
    def search(self):
        con = sqlite3.connect(database="rms.db")
        cur = con.cursor()
        try:
            cur.execute("SELECT name, course FROM student WHERE roll=?", (self.var_roll.get(),))
            row = cur.fetchone()
            if row is not None:
                self.var_name.set(row[0])
                self.var_course.set(row[1])
            else:
                messagebox.showerror("Error", "No record found", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to {str(ex)}", parent=self.root)

    # ===== Add Result Function =====
    def add(self):
        con = sqlite3.connect(database="rms.db")
        cur = con.cursor()
        try:
            if self.var_name.get() == "":
                messagebox.showerror("Error", "Please first search student's record", parent=self.root)
            elif self.var_marks.get() == "" or self.var_full_marks.get() == "":
                messagebox.showerror("Error", "Please enter marks and full marks", parent=self.root)
            else:
                cur.execute("SELECT * FROM result WHERE roll=? AND course=?", (self.var_roll.get(), self.var_course.get()))
                row = cur.fetchone()
                if row is not None:
                    messagebox.showerror("Error", "Result already present", parent=self.root)
                else:
                    try:
                        marks_obt = int(self.var_marks.get())
                        full_marks = int(self.var_full_marks.get())
                        per = (marks_obt * 100) / full_marks
                    except:
                        messagebox.showerror("Error", "Marks must be valid integers", parent=self.root)
                        return

                    cur.execute("INSERT INTO result(roll, name, course, marks_ob, full_marks, per) VALUES (?, ?, ?, ?, ?, ?)",
                                (
                                    self.var_roll.get(),
                                    self.var_name.get(),
                                    self.var_course.get(),
                                    marks_obt,
                                    full_marks,
                                    str(round(per, 2))
                                ))
                    con.commit()
                    messagebox.showinfo("Success", "Result Added Successfully", parent=self.root)
                    self.clear()

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to {str(ex)}", parent=self.root)

    # ===== Clear Form =====
    def clear(self):
        self.var_roll.set("Select")
        self.var_name.set("")
        self.var_course.set("")
        self.var_marks.set("")
        self.var_full_marks.set("")

# ===== Main Function =====
if __name__ == "__main__":
    root = Tk()
    obj = resultClass(root)
    root.mainloop()
