# -*- coding: utf-8 -*-
"""
Created on Sun Apr 20 17:18:12 2025
@author: Admin
"""

from tkinter import *
from PIL import Image, ImageTk, ImageDraw
from datetime import datetime
from math import sin, cos, radians

class Clock:
    def __init__(self, root):
        self.root = root
        self.root.title("GUI Analog Clock")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#021e2f")

        # Title label (centered)
        title = Label(
            self.root, text="Analog Clock",
            font=("times new roman", 50, "bold"),
            bg="#04444a", fg="white"
        )
        title.place(x=0, y=50, relwidth=1)

        # Clock display label (for showing image)
        self.lbl = Label(self.root, bg="white", bd=10, relief=RAISED)
        self.lbl.place(x=450, y=150, height=400, width=400)

        # Start updating clock
        self.working()

    def clock_image(self, hr, min_, sec_):
        # Create a white base image
        clock = Image.new("RGB", (400, 400), (255, 255, 255))
        draw = ImageDraw.Draw(clock)

        # Load and paste clock background image
        bg = Image.open("images/cl.jpg")
        bg = bg.resize((300, 300), Image.ANTIALIAS)
        clock.paste(bg, (50, 50))

        # Clock center point
        origin = 200, 200

        # Draw hour hand
        draw.line(
            (origin, 200 + 50 * sin(radians(hr)), 200 - 50 * cos(radians(hr))),
            fill="black", width=4
        )

        # Draw minute hand
        draw.line(
            (origin, 200 + 80 * sin(radians(min_)), 200 - 80 * cos(radians(min_))),
            fill="blue", width=3
        )

        # Draw second hand
        draw.line(
            (origin, 200 + 100 * sin(radians(sec_)), 200 - 100 * cos(radians(sec_))),
            fill="green", width=2
        )

        # Draw center circle
        draw.ellipse((195, 195, 210, 210), fill="black")

        # Save the clock image
        clock.save("clock_new.png")

    def working(self):
        # Get current time
        h = datetime.now().time().hour
        m = datetime.now().time().minute
        s = datetime.now().time().second

        # Convert time to degrees
        hr = (h % 12) * 30 + (m / 60) * 30  # 360/12 = 30 deg per hour
        min_ = (m / 60) * 360
        sec_ = (s / 60) * 360

        # Update clock image
        self.clock_image(hr, min_, sec_)

        # Load and show the new image
        self.img = ImageTk.PhotoImage(file="clock_new.png")
        self.lbl.config(image=self.img)

        # Call itself after 200 ms
        self.lbl.after(200, self.working)

# Run the application
root = Tk()
obj = Clock(root)
root.mainloop()
