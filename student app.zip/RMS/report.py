from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import sqlite3

class reportClass:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Result Management System")
        self.root.geometry("1200x480+80+170")
        self.root.config(bg="white")
        self.root.focus_force()

        # ===== Title Label =====
        title = Label(self.root, text="View Student Results",
                      font=("goudy old style", 20, "bold"),
                      bg="orange", fg="#262626")
        title.place(x=10, y=15, width=1180, height=50)

        # ==== Search ======
        self.var_search = StringVar()

        lbl_search = Label(self.root, text="Search By Roll No.", font=("goudy old style", 20, "bold"), bg="white")
        lbl_search.place(x=280, y=100)

        txt_search = Entry(self.root, textvariable=self.var_search, font=("goudy old style", 20), bg="lightyellow")
        txt_search.place(x=520, y=100, width=150)

        btn_search = Button(self.root, text='Search', font=("goudy old style", 15, "bold"),
                            bg="#03a9f4", fg="white", cursor="hand2", command=self.search)
        btn_search.place(x=680, y=100, width=100, height=35)

        btn_clear = Button(self.root, text='Clear', font=("goudy old style", 15, "bold"),
                           bg="gray", fg="white", cursor="hand2", command=self.clear)
        btn_clear.place(x=800, y=100, width=100, height=35)

        # ===== Labels =====
        Label(self.root, text="Roll No", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=150, y=230, width=150, height=50)
        Label(self.root, text="Name", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=300, y=230, width=150, height=50)
        Label(self.root, text="Course", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=450, y=230, width=150, height=50)
        Label(self.root, text="Marks Obtained", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=600, y=230, width=150, height=50)
        Label(self.root, text="Total Marks", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=750, y=230, width=150, height=50)
        Label(self.root, text="Percentage", font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE).place(x=900, y=230, width=150, height=50)

        # Dynamic value labels
        self.roll = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.roll.place(x=150, y=280, width=150, height=50)

        self.name = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.name.place(x=300, y=280, width=150, height=50)

        self.course = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.course.place(x=450, y=280, width=150, height=50)

        self.marks = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.marks.place(x=600, y=280, width=150, height=50)

        self.full = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.full.place(x=750, y=280, width=150, height=50)

        self.per = Label(self.root, font=("goudy old style", 15, "bold"), bg="white", bd=2, relief=GROOVE)
        self.per.place(x=900, y=280, width=150, height=50)

        # ===== Button Delete =====
        btn_delete = Button(self.root, text='Delete', font=("goudy old style", 15, "bold"),
                            bg="red", fg="white", cursor="hand2", command=self.delete)
        btn_delete.place(x=500, y=350, width=100, height=35)

    # ===== Function to search result =====
    def search(self):
        try:
            if self.var_search.get().strip() == "":
                messagebox.showerror("Error", "Roll No. should be required", parent=self.root)
                return

            con = sqlite3.connect(database="rms.db")
            cur = con.cursor()
            cur.execute("SELECT * FROM result WHERE roll=?", (self.var_search.get().strip(),))
            row = cur.fetchone()
            con.close()

            if row is not None:
                self.roll.config(text=row[1])
                self.name.config(text=row[2])
                self.course.config(text=row[3])
                self.marks.config(text=row[4])
                self.full.config(text=row[5])
                self.per.config(text=row[6])
            else:
                messagebox.showerror("Error", "No record found", parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    # ===== Clear all labels =====
    def clear(self):
        self.var_search.set("")
        self.roll.config(text="")
        self.name.config(text="")
        self.course.config(text="")
        self.marks.config(text="")
        self.full.config(text="")
        self.per.config(text="")

    # ===== Optional: Delete record from database =====
    def delete(self):
        try:
            roll = self.var_search.get().strip()
            if roll == "":
                messagebox.showerror("Error", "Please enter a Roll No. to delete", parent=self.root)
                return

            con = sqlite3.connect(database="rms.db")
            cur = con.cursor()
            cur.execute("SELECT * FROM result WHERE roll=?", (roll,))
            row = cur.fetchone()

            if row is None:
                messagebox.showerror("Error", "No record found", parent=self.root)
            else:
                confirm = messagebox.askyesno("Confirm", "Are you sure you want to delete this record?", parent=self.root)
                if confirm:
                    cur.execute("DELETE FROM result WHERE roll=?", (roll,))
                    con.commit()
                    messagebox.showinfo("Success", "Record deleted successfully", parent=self.root)
                    self.clear()

            con.close()

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

# ===== Main Call =====
if __name__ == "__main__":
    root = Tk()
    obj = reportClass(root)
    root.mainloop()
